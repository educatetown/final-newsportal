from django.apps import AppConfig


class TechConfig(AppConfig):
    name = 'tech'

from django.apps import AppConfig


class NewsportalappConfig(AppConfig):
    name = 'newsportalapp'

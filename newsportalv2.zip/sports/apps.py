from django.apps import AppConfig


class SportsConfig(AppConfig):
    name = 'sports'

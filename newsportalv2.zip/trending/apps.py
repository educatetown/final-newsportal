from django.apps import AppConfig


class TrendingConfig(AppConfig):
    name = 'trending'

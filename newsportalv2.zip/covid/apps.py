from django.apps import AppConfig


class CovidConfig(AppConfig):
    name = 'covid'

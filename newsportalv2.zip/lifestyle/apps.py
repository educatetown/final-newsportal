from django.apps import AppConfig


class LifestyleConfig(AppConfig):
    name = 'lifestyle'

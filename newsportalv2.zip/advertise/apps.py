from django.apps import AppConfig


class AdvertiseConfig(AppConfig):
    name = 'advertise'

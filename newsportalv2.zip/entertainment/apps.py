from django.apps import AppConfig


class EntertainmentConfig(AppConfig):
    name = 'entertainment'
